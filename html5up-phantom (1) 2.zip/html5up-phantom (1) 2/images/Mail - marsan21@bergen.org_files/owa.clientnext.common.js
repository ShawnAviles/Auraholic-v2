﻿window.scriptsLoaded = window.scriptsLoaded || {}; window.scriptProcessStart = window.scriptProcessStart || {}; window.scriptProcessStart['owa.clientnext.common.js'] = (new Date()).getTime();
// Empty on purpose;
window.scriptsLoaded['owa.clientnext.common.js'] = 1; window.scriptProcessEnd = window.scriptProcessEnd || {}; window.scriptProcessEnd['owa.clientnext.common.js'] = (new Date()).getTime();
